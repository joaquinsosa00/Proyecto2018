/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unt.herrera.prog2.tp7.gui.principal.controladores;

import java.util.Objects;

public class Trabajo {    
    private String titulo;
    private String duracion;
    private String areas;
    private String fechaPresentacion;
    private String fechaExposicion;
    private String fechaAprobacion;
    
    
    /**
     * Constructor
     * @param nombre titulo del establecimiento
     * @param domicilio duracion del establecimiento
     * @param codigo código del establecimiento
     * @param tipo tipo de establecimiento (Público o Privado)
    */                                                                                                
    public Trabajo(String nombre, String domicilio, String codigo) {
        this.titulo = nombre;
        this.duracion = domicilio;
        this.areas = codigo;
        
    }

    public Trabajo(String titulo, String duracion, String areas, String fechaPresentacion, String fechaExposicion, String fechaAprobacion) {
        this.titulo = titulo;
        this.duracion = duracion;
        this.areas = areas;
        this.fechaPresentacion = fechaPresentacion;
        this.fechaExposicion = fechaExposicion;
        this.fechaAprobacion = fechaAprobacion;
    }
    
    public String getTitulo() {
        return this.titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDuracion() {
        return this.duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String getAreas() {
        return this.areas;
    }

    public void setAreas(String areas) {
        this.areas = areas;
    }

    

    /**
     * Devuelve el hashCode del objeto
     * @return int  - hashCode del objeto
    */                                                                                                            
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 79 * hash + Objects.hashCode(this.areas);
        return hash;
    }

    /**
     * Compara si 2 establecimientos son iguales según el código
     * @return boolean
    */                                                                                                        
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass().getSuperclass() != obj.getClass().getSuperclass()) {
            return false;
        }
        final Trabajo other = (Trabajo) obj;
        if (!Objects.equals(this.areas, other.areas)) {
            return false;
        }
        return true;
    }

    public String getFechaPresentacion() {
        return fechaPresentacion;
    }

    public void setFechaPresentacion(String fechaPresentacion) {
        this.fechaPresentacion = fechaPresentacion;
    }

    public String getFechaExposicion() {
        return fechaExposicion;
    }

    public void setFechaExposicion(String fechaExposicion) {
        this.fechaExposicion = fechaExposicion;
    }

    public String getFechaAprobacion() {
        return fechaAprobacion;
    }

    public void setFechaAprobacion(String fechaAprobacion) {
        this.fechaAprobacion = fechaAprobacion;
    }
}
    
