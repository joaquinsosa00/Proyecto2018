/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unt.herrera.prog2.tp7.gui.principal.controladores;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionListener;

public class ControladorVentanaJFrame {
    private static ControladorVentanaJFrame instancia;
    private Ventana ventana;
    
    /**
     * Constructor
    */                                            
    private ControladorVentanaJFrame() {
        this.ventana = new Ventana(this);
        this.configurarTabla();        
        this.ventana.setVisible(true);
    }
    
    /**
     * Configura la tabla de establecimientos
     */    
    private void configurarTabla() {
        JTable tablaTrabajos = this.ventana.getTablaTrabajo();
        tablaTrabajos.setModel(new ModeloTablaTrabajos());
        
        tablaTrabajos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        //para que sólo se pueda seleccionar una fila en la tabla

        ListSelectionListener lsl = (e) -> {            
            if (!e.getValueIsAdjusting()) {
                //En esta tabla se puede seleccionar sólo un elemento a la vez, 
                //por lo que cuando se realiza una nueva selección, 
                //el elemento seleccionado anteriormente se convierte en no seleccionado, 
                //disparándose 2 eventos cada vez que se selecciona un elemento diferente
                //Para evitar responder al evento cuando un elemento deja de estar seleccionado
                //y luego cuando otro queda seleccionado, se comprueba que esta secuencia de eventos
                //esté terminada mediante getValueIsAdjusting()
                int fila = tablaTrabajos.getSelectedRow(); 
                ModeloTablaTrabajos mtt = (ModeloTablaTrabajos)tablaTrabajos.getModel();
                Trabajo unTrabajo = mtt.obtenerTrabajo(fila);
                JOptionPane.showMessageDialog(null, "Código del trabajo seleccionado: " + unTrabajo.getAreas(), "Mi ventana (JFrame)", JOptionPane.INFORMATION_MESSAGE);
            }                       
        };
        
        tablaTrabajos.getSelectionModel().addListSelectionListener(lsl);
    }
    
    /**
     * Método estático que permite crear una única instancia de ControladorVentanaJFrame
     * @return ControladorVentanaJFrame
    */                                                            
    public static ControladorVentanaJFrame instanciar() {
        if (instancia == null) 
            instancia = new ControladorVentanaJFrame();            
        return instancia;
    } 
    
    public void btnCancelarClic() {
        this.ventana.dispose();
    }
    
    
    
        
    
    public void rbOpcion1Clic() {
        JOptionPane.showMessageDialog(null, "Opción 1 seleccionada", "Mi ventana (JFrame)", JOptionPane.INFORMATION_MESSAGE);
    }
}
