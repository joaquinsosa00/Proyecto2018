/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unt.herrera.prog2.tp7.gui.principal.controladores;

import java.util.ArrayList;
import java.util.List;

public class GestorTrabajo {
    public static final String OPERACION_EXITO = "Establecimiento creado con éxito";
    public static final String OPERACION_DUPLICADOS = "Ya existe un establecimiento con ese código";
    public static final String OPERACION_ERROR = "El nombre, domicilio y código del establecimiento no pueden ser nulos";
    
    private List<Trabajo> Trabajos = new ArrayList<>();
    private static GestorTrabajo gestor;
    
    /**
     * Constructor
    */                                            
    private GestorTrabajo() {                
    }
    
    /**
     * Método estático que permite crear una única instancia de GestorTrabajo
     * @return GestorTrabajo
    */                                                            
    public static GestorTrabajo instanciar() {
        if (gestor == null) 
            gestor = new GestorTrabajo();            
        return gestor;
    } 
    
    /**
     * Crea un nuevo establecimiento
     * @param nombre nombre del establecimiento
     * @param domicilio domicilio del establecimiento
     * @param codigo código del establecimiento
     * @param tipo tipo de establecimiento
     * @return String  - cadena con el resultado de la operación
    */                                                                
    public String crearTrabajo(String nombre, String domicilio, String codigo) {
        if ((!nombre.trim().isEmpty()) && (!domicilio.trim().isEmpty()) && (!codigo.trim().isEmpty())) { //nombre, domicilio y código del establecimiento no nulos
            Trabajo unEstablecimiento = new Trabajo(nombre, domicilio, codigo);
            if (!this.Trabajos.contains(unEstablecimiento)) { //no existe este establecimiento
                this.Trabajos.add(unEstablecimiento);
                return OPERACION_EXITO;
            }
            else //ya existe un establecimiento con este código
                return OPERACION_DUPLICADOS;
        }
        else { //nombre, domicilio y/o código del establecimiento nulos
           return OPERACION_ERROR;
        }        
    }
    public String crearTrabajo(String nombre, String domicilio, String codigo,String area, String fecha, String fechae) {
        if ((!nombre.trim().isEmpty()) && (!domicilio.trim().isEmpty()) && (!codigo.trim().isEmpty())) { //nombre, domicilio y código del establecimiento no nulos
            Trabajo unEstablecimiento = new Trabajo(nombre, domicilio, codigo,area,fecha,fechae);
            if (!this.Trabajos.contains(unEstablecimiento)) { //no existe este establecimiento
                this.Trabajos.add(unEstablecimiento);
                return OPERACION_EXITO;
            }
            else //ya existe un establecimiento con este código
                return OPERACION_DUPLICADOS;
        }
        else { //nombre, domicilio y/o código del establecimiento nulos
           return OPERACION_ERROR;
        }        
    }
    
    /**
     * Devuelve el establecimiento que se encuentra en la posición especificada
     * Este método es para la GUI por lo que no hacen falta otros controles
     * @param posicion posición dentro del ArrayList
     * @return Trabajo  - establecimiento que se encuentra en la posición especificada
     */
    public Trabajo obtenerTrabajo(int posicion) {
        return this.Trabajos.get(posicion);
    }
    
    /**
     * Devuelve la cantidad de establecimientos
     * @return int  - cantidad de establecimientos
     */
    public int cantTrabajos() {
        return this.Trabajos.size();
    }

}
