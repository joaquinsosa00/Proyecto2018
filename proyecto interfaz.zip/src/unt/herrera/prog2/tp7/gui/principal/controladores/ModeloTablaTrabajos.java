/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unt.herrera.prog2.tp7.gui.principal.controladores;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class ModeloTablaTrabajos extends AbstractTableModel {
    //los datos los saca de GestorTrabajo
    private List<String> nombresColumnas = new ArrayList<>();        
    //colección para guardar los nombres de las columnas
    private GestorTrabajo ge = GestorTrabajo.instanciar();  
    
    /**
    * Constructor
    */                                                        
    public ModeloTablaTrabajos() {
        this.nombresColumnas.add("Titulo");
        this.nombresColumnas.add("Duracion");        
        this.nombresColumnas.add("Area");        
        this.nombresColumnas.add("Fecha Presentacion");        
        this.nombresColumnas.add("Fecha Aprobacion");        
        this.nombresColumnas.add("Fecha Exposicion");        
    }    
    
    
    /**
    * Obtiene el valor de la celda especificada
    * @param fila fila de la celda
    * @param columna columna de la celda
    * @return Object  - valor de la celda
    */                        
    @Override
    public Object getValueAt(int fila, int columna) {
        Trabajo unTrabajo = this.ge.obtenerTrabajo(fila);
        switch (columna) {
            //No se muestra el código del establecimiento
            case 0: return unTrabajo.getTitulo();
            case 1: return unTrabajo.getDuracion();
            case 2: return unTrabajo.getAreas();
            case 3: return unTrabajo.getFechaPresentacion();
            case 4: return unTrabajo.getFechaAprobacion();
            case 5: return unTrabajo.getFechaExposicion();
            default: return "       -";
        }
    }
    
    /**
    * Obtiene la cantidad de columnas de la tabla
    * @return int  - cantidad de columnas de la tabla
    */                            
    @Override
    public int getColumnCount() { 
        return this.nombresColumnas.size();
    }

    /**
    * Obtiene la cantidad de filas de la tabla
    * @return int  - cantidad de filas de la tabla
    */                        
    @Override
    public int getRowCount() { 
        return this.ge.cantTrabajos();
    }

    /**
    * Obtiene el nombre de una columna
    * @param columna columna sobre la que se quiere obtener el nombre
    * @return String  - nombre de la columna especificada
    */                        
    @Override
    public String getColumnName(int columna) {
        return this.nombresColumnas.get(columna);
    }

    /**
    * Devuelve el Trabajo correspondiente a la fila especificada dentro de la tabla
    * @param fila fila dentro de la tabla
    * @return Trabajo  - objeto Trabajo correspondiente a la fila que se especifica
    * @see Trabajo
    */        
    public Trabajo obtenerTrabajo(int fila) {
        return this.ge.obtenerTrabajo(fila);
    }    
}
